import Headerbar from './Headerbar';
function Home(){
    return (
    <>
    <Headerbar/>
    </>
    )
}

export default Home;