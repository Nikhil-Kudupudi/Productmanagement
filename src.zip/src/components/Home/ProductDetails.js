import { FaRegEdit } from 'react-icons/fa';
import { useState } from 'react';
import React from "react";

const IconChange=({task})=>{
    const [edit, setedit] = useState(false);

    const updatechanges = () => {
        setedit(!edit);
        console.log(edit);
    }

    return (
        <>
        <React.Fragment key={task.key}>
        <tr >
        <td >{task.Name}</td>
        <td contentEditable={edit}>{task.Cost}</td>
        <td contentEditable={edit}>{task.Quantity}</td>
        <td contentEditable={edit}>{task.CompanyName}</td>
        <td className="col-sm-10" key={task.id}>{!edit?<FaRegEdit onClick={updatechanges}/>:<button type="button" className='btn btn-primary' onClick={updatechanges}>save</button>}</td>
        </tr>
        </React.Fragment>
        </>
    )


}
function ProductDetails() {

   
  
    const [tasks, settasks] = useState([
        {
            id: 1,
            Name: "Pn",
            Cost: 123,
            Quantity: 23,
            CompanyName: "abc"
        },
        {
            id: 2,
            Name: "sjdf",
            Cost: 123,
            Quantity: 23,
            CompanyName: "abc"
        },
        {
            id: 3,
            Name: "sjdnfj",
            Cost: 123,
            Quantity: 23,
            CompanyName: "abc"
        }
    ])



    return (
        <div className="">
            <div className="container-fluid">
                <h1>Product Details</h1>
            </div>
            <table className="table table-striped table-inverse table-responsive">
                <thead className="thead-inverse">
                    <tr>
                        <th>Product Name</th>
                        <th>Cost</th>
                        <th>Quantity</th>
                        <th> Company Name</th>
                    </tr>
                </thead>
                <tbody>
                    {

                        tasks.map((task) => (

                           <IconChange task={task}/> 
                        ))
                    }



                </tbody>
            </table>
        </div>

    )
}
export default ProductDetails;