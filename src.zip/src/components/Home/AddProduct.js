import axios from "axios";
import { useState,useEffect } from "react";

const AddProduct=()=>{
  const [info, setinfo] = useState(
    {
    Productid:'',
    Productname:'',
    Cost:0,
    Quantity:0,
    CompanyName:''
    }
  );
const [Product, setProduct] = useState({
  email:localStorage.getItem("email"),
  items:[
    info
  ]
  
});
const [isempty,setisEmpty ]=useState(false);
// axios.post("http:localhost:8080/addproduct",Product);



const [formerrors, setformerrors] = useState({});
const handleChange=(evt)=>{
  setinfo({...info,[evt.target.name]:evt.target.value});
}
const handleSubmit=()=>{
  setformerrors(validate(info))
}

const validate=(values)=>{
  const errors={};
  if(!values.Productname){
    errors.Productname="product name is required";
  }
  if(!values.CompanyName){
    errors.CompanyName="company name is required";
  }
  if(values.Cost===0){
    errors.Cost="Cost should not be zero";
  }
  if(values.Quantity===0){
      errors.Quantity="Quantity should be greater than 0 ";
  }
}


    return (
        <>
        <div className="container-fluid">
            <h1>Add Product</h1>
        </div>
        <form onClick={handleSubmit}>
        <div className="mb-3">
       <label htmlFor="Productid" className="form-label">Product Name</label>
       <input type="text" name="Productid" id="Productid" value={info.Productid} onChange={handleChange} className="form-control" placeholder="" aria-describedby="helpId" required/>
       <small id="helpId" className="text-danger">{formerrors.Productid}</small>
     </div>
     <div className="mb-3">
       <label htmlFor="Productname" className="form-label">Product Name</label>
       <input type="text" name="Productname" id="Productname" value={info.Productname} onChange={handleChange}className="form-control" placeholder="" aria-describedby="helpId"/>
       <small id="helpId" className="text-danger">{formerrors.Productname}</small>
     </div>
     <div className="form-group">
       <label htmlFor="Cost">Cost</label>
       <input type="number" name="Cost" id="Cost"  value={info.Cost} onChange={handleChange} className="form-control" placeholder="" aria-describedby="helpId"/>
       <small id="helpId" className="text-danger">{formerrors.Cost}</small>
     </div>
     <div className="form-group">
       <label htmlFor="Quantity">Quantity</label>
       <input type="number" name="Quantity" id="Quantity" value={info.Quantity} onChange={handleChange} className="form-control" placeholder="" aria-describedby="helpId"/>
       <small id="helpId" className="text-danger">{formerrors.Quantity}</small>
     </div>
        <div className="form-group">
          <label htmlFor="Companyname">Company Name</label>
          <input type="text" name="Companyname" id="Companyname" value={info.CompanyName} onChange={handleChange} className="form-control" placeholder="" aria-describedby="helpId"/>
          <small id="helpId" className="text-danger">{formerrors.CompanyName}</small>
        </div>
        <button type="Submit" className="btn btn-primary btn-lg btn-block" >Submit</button>
     </form>

        </>
    );
}
export default AddProduct;